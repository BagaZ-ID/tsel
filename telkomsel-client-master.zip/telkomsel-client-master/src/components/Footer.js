import React , {Component} from 'react';

class Footer extends Component {
    render() {
        return (
            <footer>
                Footer
            </footer>
        )
    }
}
export default Footer;