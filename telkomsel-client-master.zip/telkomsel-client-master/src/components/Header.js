import React , {Component} from 'react';

class Header extends Component {
    render() {
        return (
            <header>
                Header
            </header>
        )
    }
}
export default Header;