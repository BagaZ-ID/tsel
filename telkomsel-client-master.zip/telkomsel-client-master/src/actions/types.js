export const REQUEST_MAGIC_LINK = 'request_magic_link';
export const AUTH_LOGIN = 'auth_login';
export const BUY_PACKAGE = 'buy_package';
export const OFFERS_PACKAGE = 'offers_package';
