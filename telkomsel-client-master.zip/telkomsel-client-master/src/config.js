const API = "https://aryadev.herokuapp.com";

export default API;